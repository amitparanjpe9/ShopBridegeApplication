﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace DataAccess
{
    public class Class1
    {
        public DataSet getCustomers()
        {     
            // open a connection
            string Connectionstring = ConfigurationManager.ConnectionStrings["ShopBridgeDB"].ToString();
            SqlConnection objConnection = new SqlConnection(Connectionstring);
            objConnection.Open();

            // Fire the command object
            // Command -- SQL - SQl server
            SqlCommand objCommand = new SqlCommand("Select * from Product", objConnection);
            DataSet objDataset = new DataSet();
            SqlDataAdapter objAdapter = new SqlDataAdapter(objCommand);

            objAdapter.Fill(objDataset);


            // Close the connection
            objConnection.Close();
            return objDataset;
        }

        public DataSet getCustomers(string CustomerCode)
        {
            // open a connection
            string Connectionstring = ConfigurationManager.ConnectionStrings["ShopBridgeDB"].ToString();
            SqlConnection objConnection = new SqlConnection(Connectionstring);
            objConnection.Open();

            // Fire the command object
            // Command -- SQL - SQl server
            SqlCommand objCommand = new SqlCommand("Select * from Product where ProductName='"
                                  + CustomerCode + "'",
                                  objConnection);
            DataSet objDataset = new DataSet();
            SqlDataAdapter objAdapter = new SqlDataAdapter(objCommand);

            objAdapter.Fill(objDataset);


            // Close the connection
            objConnection.Close();
            return objDataset;
        }

        public bool InsertCustomer(string productname, string productdescription, string price)
        {
            // Open connection
            string Connectionstring = ConfigurationManager.ConnectionStrings["ShopBridgeDB"].ToString();
            SqlConnection objConnection = new SqlConnection(Connectionstring);
            objConnection.Open();
            try
            {

                // Command insert fire
                string strInsertCommand = "insert into Product values('"
                                                    + productname + "','"
                                                    + productdescription + "',"
                                                    + price + ")";


                SqlCommand objCommand = new SqlCommand(strInsertCommand, objConnection);
                objCommand.ExecuteNonQuery();
                // close connection

                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
            finally
            {
                objConnection.Close();
            }

        }

        public bool DeleteCustomer(string strProductName)
        {
            string Connectionstring = ConfigurationManager.ConnectionStrings["ShopBridgeDB"].ToString();
            SqlConnection objConnection = new SqlConnection(Connectionstring);
            objConnection.Open();

            // Fire the command object
            // Command -- SQL - SQl server
            SqlCommand objCommand = new SqlCommand("delete from Product where ProductName='"
                                    + strProductName + "'",
                                    objConnection);

            objCommand.ExecuteNonQuery();
            objConnection.Close();
            return true;
        }

        public bool UpdateCustomer(string strProductName,
                                    string strProductDescription,
                                    string strPrice)
        {
            // Open connection
            string Connectionstring = ConfigurationManager.ConnectionStrings["ShopBridgeDB"].ToString();
            SqlConnection objConnection = new SqlConnection(Connectionstring);
            objConnection.Open();
            // Command insert fire
            string strUpdateCommand = "Update Product set ProductName='"
                                                + strProductName + "', ProductDescription='"
                                                + strProductDescription + "',Price='"
                                                + strPrice + "' where ProductName = '" + strProductName + "'";

            SqlCommand objCommand = new SqlCommand(strUpdateCommand, objConnection);
            objCommand.ExecuteNonQuery();
            // close connection
            objConnection.Close();
            return true;
        }

    }
}
