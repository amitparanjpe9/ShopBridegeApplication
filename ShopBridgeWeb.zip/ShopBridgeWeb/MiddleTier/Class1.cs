﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess;
using System.Data;
using System.Data.SqlClient;


namespace MiddleTier
{
    public class Product
    {
        private string _ProductName = "";
        private string _ProductDescription = "";
        private string _Price = "";
        public string ProductName
        {
            get { return _ProductName; }
            set
            {
                if(value.Length == 0)
                {
                    throw new Exception("Please enter the product name");
                }
                _ProductName = value;
            }
        }        

        public string ProductDescription
        {
            get { return _ProductDescription; }
            set
            {
                if(value.Length == 0)
                {
                    throw new Exception("Product Description is required");
                }
                _ProductDescription = value;
            }

        }
       
        public string Price
        {
            get { return _Price; }
            set
            {
                if(value.Length == 0)
                {
                    throw new Exception("Plaese enter the price");
                }
                _Price = value;
            }
        }

        public void Save()
        {
            Class1 obj = new Class1();
            obj.InsertCustomer(_ProductName, _ProductDescription, _Price);
        }

        public void Delete()
        {
            Class1 obj = new Class1();
            obj.DeleteCustomer(_ProductName);
        }

        public void Update()
        {
            Class1 obj = new Class1();
            obj.UpdateCustomer(_ProductName, _ProductDescription, _Price);

        }
        public DataSet LoadCustomer()
        {
            Class1 obj = new Class1();
            return obj.getCustomers();
        }
        public DataSet LoadCustomer(string CustomerName)
        {
            Class1 obj = new Class1();
            return obj.getCustomers(CustomerName);
        }




    }
}
