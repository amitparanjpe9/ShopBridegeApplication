﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using MiddleTier;

namespace ShopBridgeWeb
{
    public partial class ShopBridge : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            LoadCustomers();
        }

        private void LoadCustomers()
        {
            Product obj = new Product();
            GridShopBridge.DataSource = obj.LoadCustomer().Tables[0];
            GridShopBridge.DataBind();
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            // create the object of the class
            // ADO.NET code which will inset to SQL server

            // ADO.NET code which will inset to SQL server
            Product obj = new Product();
            obj.ProductName = ddlProductName.Text;
            obj.ProductDescription = txtProductDescription.Text;
            obj.Price = txtPrice.Text;
            obj.Save();
            LoadCustomers();
            ClearData();

        }

        private void ClearData()
        {
            ddlProductName.Text = "";
            txtProductDescription.Text = "";
            txtPrice.Text = "";
        }

        protected void GridShopBridge_SelectedIndexChanged(object sender, EventArgs e)
        {
            //First we are clearing the data
            ClearData();
            // get the selected customer name by the end user from the grid
            string strCustomerName = GridShopBridge.Rows[GridShopBridge.SelectedIndex].Cells[1].Text;
            // select the data which is currently clicked
            DisplayCustomer(strCustomerName); 

        }

        private void DisplayCustomer(string CustomerCode)
        {
            Product  obj = new Product();
            DataSet objDataset = obj.LoadCustomer(CustomerCode);


            // Select the records and display it on the screen
            string strProductName = objDataset.Tables[0].Rows[0][0].ToString();
            string strProductDescription = objDataset.Tables[0].Rows[0][1].ToString();
            string strPrice = objDataset.Tables[0].Rows[0][2].ToString();

            ddlProductName.Text = strProductName;
            txtProductDescription.Text = strProductDescription;
            txtPrice.Text = strPrice;           
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            //here we will write down the logic of updating the database

            Product obj = new Product();
            obj.ProductName = ddlProductName.SelectedIndex.ToString();
            obj.ProductDescription = txtProductDescription.Text;
            obj.Price = txtPrice.Text;
            obj.Update();

            LoadCustomers();
            ClearData();

        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            //here the delete logic will go

            Product obj = new Product();
            obj.Delete();
            ClearData();
            LoadCustomers();
        }
    }
}